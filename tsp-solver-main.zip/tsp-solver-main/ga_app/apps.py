from django.apps import AppConfig


class GaAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ga_app'
