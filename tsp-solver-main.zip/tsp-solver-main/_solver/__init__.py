from .tsp import solve_tsp
from .ga import solve_tsp_ga
from .aco import solve_tsp_aco
from .hbc import solve_tsp_hbc
from .sa import solve_tsp_sa
