from django.apps import AppConfig


class TspAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tsp_app'
