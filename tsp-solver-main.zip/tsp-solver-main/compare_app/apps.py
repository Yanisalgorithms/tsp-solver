from django.apps import AppConfig


class CompareAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'compare_app'
